Verdantica Colloid accent overlay: Oat Cream (cream)
Solstice accent: #E4D2B5
Nocturne accent: #E4D2B5

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
