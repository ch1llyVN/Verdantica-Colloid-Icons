Verdantica Colloid accent overlay: Dusty Sage (sage)
Solstice accent: #AAB49A
Nocturne accent: #AAB49A

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
