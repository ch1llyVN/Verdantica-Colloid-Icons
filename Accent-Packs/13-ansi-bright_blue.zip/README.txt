Verdantica Colloid accent overlay: Morning Blue (ansi-bright_blue)
Solstice accent: #7898AF
Nocturne accent: #B1C8D9

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
