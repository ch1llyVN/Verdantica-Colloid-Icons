Verdantica Colloid accent overlay: Coffee Cream (coffee)
Solstice accent: #C6A17B
Nocturne accent: #C6A17B

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
