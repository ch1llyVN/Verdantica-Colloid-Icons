Verdantica Colloid accent overlay: Patina (ansi-cyan)
Solstice accent: #527F78
Nocturne accent: #8DBBB0

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
