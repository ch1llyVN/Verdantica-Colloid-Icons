Verdantica Colloid accent overlay: Burnished Copper (copper)
Solstice accent: #AD7656
Nocturne accent: #AD7656

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
