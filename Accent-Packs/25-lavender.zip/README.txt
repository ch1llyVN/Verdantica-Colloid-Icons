Verdantica Colloid accent overlay: Dried Lavender (lavender)
Solstice accent: #A99BB2
Nocturne accent: #A99BB2

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
