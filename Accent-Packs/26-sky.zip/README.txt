Verdantica Colloid accent overlay: Faded Sky (sky)
Solstice accent: #91AAB0
Nocturne accent: #91AAB0

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
