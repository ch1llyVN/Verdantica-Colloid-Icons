Verdantica Colloid accent overlay: Antique Brass (ansi-yellow)
Solstice accent: #98743F
Nocturne accent: #D0AD70

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
