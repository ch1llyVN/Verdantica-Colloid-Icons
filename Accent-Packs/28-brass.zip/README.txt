Verdantica Colloid accent overlay: Old Brass (brass)
Solstice accent: #B39A67
Nocturne accent: #B39A67

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
