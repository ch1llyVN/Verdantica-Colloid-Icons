Verdantica Colloid accent overlay: Dried Rose (rose)
Solstice accent: #BB8E8A
Nocturne accent: #BB8E8A

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
