Verdantica Colloid accent overlay: Ink Shadow (ansi-black)
Solstice accent: #D8CEBA
Nocturne accent: #19140F

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
