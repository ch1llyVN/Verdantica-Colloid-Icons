Verdantica Colloid accent overlay: Heather (ansi-bright_magenta)
Solstice accent: #A48AA0
Nocturne accent: #CEB5CC

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
