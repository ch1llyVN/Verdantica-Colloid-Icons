Verdantica Colloid accent overlay: Slate Blue (ansi-blue)
Solstice accent: #58758C
Nocturne accent: #91ADC3

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
