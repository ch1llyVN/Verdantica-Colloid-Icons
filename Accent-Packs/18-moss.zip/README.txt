Verdantica Colloid accent overlay: Forest Moss (moss)
Solstice accent: #697B50
Nocturne accent: #697B50

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
