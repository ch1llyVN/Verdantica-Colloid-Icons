Verdantica Colloid accent overlay: Newsprint (ansi-white)
Solstice accent: #F3EBDD
Nocturne accent: #E9DCC5

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
