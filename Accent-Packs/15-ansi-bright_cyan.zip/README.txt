Verdantica Colloid accent overlay: Mist (ansi-bright_cyan)
Solstice accent: #83AAA0
Nocturne accent: #B1D5C8

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
