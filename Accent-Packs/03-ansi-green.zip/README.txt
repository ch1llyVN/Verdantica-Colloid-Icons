Verdantica Colloid accent overlay: Botanical (ansi-green)
Solstice accent: #557A45
Nocturne accent: #A3C783

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
