Verdantica Colloid accent overlay: Ivory (ansi-bright_white)
Solstice accent: #FFF8E9
Nocturne accent: #F6EBDD

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
