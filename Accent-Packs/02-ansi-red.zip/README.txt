Verdantica Colloid accent overlay: Terracotta (ansi-red)
Solstice accent: #A95F50
Nocturne accent: #CB7968

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
