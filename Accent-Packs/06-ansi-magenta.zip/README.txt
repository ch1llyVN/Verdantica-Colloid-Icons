Verdantica Colloid accent overlay: Mulberry (ansi-magenta)
Solstice accent: #86677F
Nocturne accent: #B49AB5

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
