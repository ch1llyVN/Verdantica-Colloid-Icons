Verdantica Colloid accent overlay: Olive Branch (olive)
Solstice accent: #858B58
Nocturne accent: #858B58

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
