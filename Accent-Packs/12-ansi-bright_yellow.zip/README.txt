Verdantica Colloid accent overlay: Toasted Gold (ansi-bright_yellow)
Solstice accent: #B99A61
Nocturne accent: #E2C58B

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
