Verdantica Colloid accent overlay: Fern Green (fern)
Solstice accent: #A1B58A
Nocturne accent: #A1B58A

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
