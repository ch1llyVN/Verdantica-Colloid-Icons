Verdantica Colloid accent overlay: Graphite (ansi-bright_black)
Solstice accent: #A69A85
Nocturne accent: #665749

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
