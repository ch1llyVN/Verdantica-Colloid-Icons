Verdantica Colloid accent overlay: Fired Clay (clay)
Solstice accent: #B77D69
Nocturne accent: #B77D69

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
