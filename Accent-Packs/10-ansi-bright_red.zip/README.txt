Verdantica Colloid accent overlay: Rosewood (ansi-bright_red)
Solstice accent: #C27C6B
Nocturne accent: #E19A85

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
