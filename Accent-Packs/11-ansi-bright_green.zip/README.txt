Verdantica Colloid accent overlay: Spring Leaf (ansi-bright_green)
Solstice accent: #789B68
Nocturne accent: #B9D99B

Extract this ZIP into ~/.local/share/icons/ (or /usr/share/icons/).
It overlays only the folder-accent SVGs in the Base pack.
